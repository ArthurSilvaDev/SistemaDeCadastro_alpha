package infos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mk
 */
public class CampoVazioException extends Exception{

    public CampoVazioException() {
    }

    public CampoVazioException(String message) {
        super(message);
    }
    
}
